﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Text;
using System.Drawing.Printing;

namespace Impression
{
    public class Caption
    {
        public string Text;
        public RectangleF rec;
        public Font fnt;

    }
}
