﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoucheAcceeDonnees
{
    public class CompteModel
    {
        public string Compte { get; set; }
        public string Intitule { get; set; }
        public string CompteResultat { get; set; }
        public string Niveau { get; set; }
        public string AnouveauDebit { get; set; }
        public string AnouveauCredit { get; set; }
    }
}
