﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoucheAcceeDonnees
{
    public class DossierModel
    {
        public string IDDossier { get; set; }
        public string RaisonSocial { get; set; }
        public string Annee { get; set; }
    }
}
