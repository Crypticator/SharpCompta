﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utilitaire;


namespace CoucheAcceeDonnees
{
    public class EcritureModel
    {
        public string CodeJournal { get; set; }
        public string Annee { get; set; }

        public string Mois { get; set; }
        public string JourMois { get; set; }
        
        public string iDate { get; set; }
        
        public string Compte { get; set; }
        public string ContrePartie { get; set; }
        public string N_Ordre { get; set; }
        public string Libelle { get; set; }
        public bool Debit { get; set; }
        public string Montant { get; set; }


        public string CodeLibelleAutomatique { get; set; }

        

      


        


    }
}
