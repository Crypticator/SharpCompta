﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoucheAcceeDonnees
{
    public class JournalModel
    {

        public string Code { get; set; }
        public string Intitule { get; set; }
        public string Compte { get; set; }
        public bool ContrePartieAutomatique { get; set; }

    }


}
