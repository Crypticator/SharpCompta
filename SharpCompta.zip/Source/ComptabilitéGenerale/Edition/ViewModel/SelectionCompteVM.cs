﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EditionCompta
{
    public class SelectionCompteVM
    {
        public bool valid { get; set; }
        public string selection { get; set; }
        public string tri { get; set; }
        public string title1 { get; set; }
        public string title2 { get; set; }
    }
}
