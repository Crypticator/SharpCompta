﻿using System;
using System.Collections;
using System.Linq;
using System.Text;

namespace EditionCompta
{
    public class ListingLibelleAutVM
    {
        public ArrayList Lignes { get; set; }

        public ListingLibelleAutVM()
        {
            Lignes = new ArrayList();
        }
    }
}
