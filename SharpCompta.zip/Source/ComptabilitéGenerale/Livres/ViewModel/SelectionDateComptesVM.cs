﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LivresCompta
{
    public class SelectionDateComptesVM
    {
        public bool valid { get; set; }
        public string compted { get; set; }
        public string comptef { get; set; }
        public string date { get; set; }
        public string idate { get; set; }

    }
}
