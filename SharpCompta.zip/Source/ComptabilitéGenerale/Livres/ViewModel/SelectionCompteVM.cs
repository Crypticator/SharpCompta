﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LivresCompta
{
    public class SelectionCompteVM
    {
        public bool valid {get; set;}
        public string cmpt { get; set; }
        public string Intl { get; set; }
        public string date1 { get; set; }
        public string date2 { get; set; }
        public string idate1 { get; set; }
        public string idate2 { get; set; }
    }
}
