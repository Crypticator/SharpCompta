﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SaisieCompta
{
    public class LigneEcriture
    {
        public string JourMois {get; set;}
        public string Compte {get; set;}
        public string CPartie {get; set;}
        public string N_Ordre { get; set; }
        public string La { get; set; }
        public string Libelle { get; set; }
        public string DC { get; set; }
        public string Montant { get; set; }
            
    }
}
